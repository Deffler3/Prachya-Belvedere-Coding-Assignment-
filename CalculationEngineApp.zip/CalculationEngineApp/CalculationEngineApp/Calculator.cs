﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationEngineApp
{
    public static class Calculator
    {
        private static List<double> constantFactors = new List<double>(){ 0.4, 0.076, -0.78, 0.95, -0.24, 1.25 };

        public static double DoCalculation(int input)
        {
            var modifiedInput = input / 1000;
            var currentTime = DateTime.Now;

            var timeBucket = currentTime.Second / 5 + currentTime.Minute + currentTime.Hour;

            return constantFactors.Sum(x => constantFactors.IndexOf(x) % 2 == 0 ? timeBucket * modifiedInput * x : timeBucket * modifiedInput / x);
        }
    }
}
