﻿using System.Diagnostics;
using System.Windows;

namespace CalculationEngineApp
{
    /*The provided application is an imitation of a (poor) theoretical value generator.
      This generator takes an integer input and generates 100,000 values to plug into a Calculator.
      The Calculator will then return an output based on each generated value.
      NOTE that this calculator will output the same values every 5 seconds for the same input.
      The outputs returned from the calculator are then bucketed into groups of 100, and the average value of each of these buckets is displayed.
      
      The purpose of this project is to take in an input number through a GUI and then update the theoretical values on the left as quickly as possible.
      The time it takes to generate and display the values should be shown as well.

      The solution should be as optimal as possible, and architected in a way that is easily readable and extendable. This includes the architecture and design of the UI code which has
      purposely been simplified and is currently suboptimal. The GUI should update as quickly as possible and be functionally user-friendly, but it does not need to have any special
      features.

      Note that in the current implementation, the values on the left do not update until the submit button is clicked.In an ideal world, these values would update as often as
      possible taking into account the input value and the 5 second buckets.
      
       You may make any modifications to this class as long as the result remains accurate.Do not modify the Calculator class.
     */
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            Values.Clear();
            stopwatch.Start();

            Calculate();

            stopwatch.Stop();

            Duration.Text = stopwatch.Elapsed.ToString();
        }

        public virtual void Calculate()
        {
            double currentValue = 0;

            var input = int.Parse(Input.Text);

            for (int i = 0; i < 100000; i++)
            {
                currentValue += Calculator.DoCalculation(input * i);

                if (i % 100 == 0)
                {
                    var printOutput = currentValue / 100;
                    currentValue = 0;
                    Values.Text += printOutput + "\n";
                }
            }
        }
    }
}
